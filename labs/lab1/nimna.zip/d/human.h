#ifndef HUMAN_H
#define HUMAN_H
#include "point.h"
#include <string>

class Human {
private:
    Point location;
    std::string name;

public:
    Human(const std::string& nam = "", double x = 0, double y = 0);
    std::string get_name() const;
    void set_name(const std::string& nam);
    Point get_point() const;
    virtual void display() const;
    ~Human(); 
};

#endif 
